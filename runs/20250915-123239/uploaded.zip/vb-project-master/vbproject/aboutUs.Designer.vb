﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class aboutUs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.detailpanel = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.aboutustext = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.backpanel = New System.Windows.Forms.Panel()
        Me.panel_info = New System.Windows.Forms.Panel()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.logopanel = New System.Windows.Forms.Panel()
        Me.detailpanel.SuspendLayout()
        Me.backpanel.SuspendLayout()
        Me.panel_info.SuspendLayout()
        Me.SuspendLayout()
        '
        'detailpanel
        '
        Me.detailpanel.Controls.Add(Me.Button6)
        Me.detailpanel.Controls.Add(Me.Button5)
        Me.detailpanel.Controls.Add(Me.Button4)
        Me.detailpanel.Controls.Add(Me.Button3)
        Me.detailpanel.Controls.Add(Me.Button2)
        Me.detailpanel.Controls.Add(Me.Button1)
        Me.detailpanel.Controls.Add(Me.aboutustext)
        Me.detailpanel.Controls.Add(Me.Label2)
        Me.detailpanel.Controls.Add(Me.Label1)
        Me.detailpanel.Location = New System.Drawing.Point(305, 0)
        Me.detailpanel.Name = "detailpanel"
        Me.detailpanel.Size = New System.Drawing.Size(436, 291)
        Me.detailpanel.TabIndex = 1
        '
        'Button6
        '
        Me.Button6.BackgroundImage = Global.vbproject.My.Resources.Resources.github
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button6.Location = New System.Drawing.Point(372, 10)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(29, 24)
        Me.Button6.TabIndex = 11
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImage = Global.vbproject.My.Resources.Resources.gmail
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button5.Location = New System.Drawing.Point(404, 10)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(29, 24)
        Me.Button5.TabIndex = 10
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackgroundImage = Global.vbproject.My.Resources.Resources.linkedin
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button4.Location = New System.Drawing.Point(341, 10)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(29, 24)
        Me.Button4.TabIndex = 9
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.vbproject.My.Resources.Resources.instagram
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Location = New System.Drawing.Point(307, 10)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(29, 24)
        Me.Button3.TabIndex = 8
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = Global.vbproject.My.Resources.Resources.twitter
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button2.Location = New System.Drawing.Point(272, 10)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(29, 24)
        Me.Button2.TabIndex = 7
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.vbproject.My.Resources.Resources.facebook
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button1.Location = New System.Drawing.Point(237, 10)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(29, 24)
        Me.Button1.TabIndex = 6
        Me.Button1.UseVisualStyleBackColor = True
        '
        'aboutustext
        '
        Me.aboutustext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.aboutustext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.aboutustext.Location = New System.Drawing.Point(21, 80)
        Me.aboutustext.Multiline = True
        Me.aboutustext.Name = "aboutustext"
        Me.aboutustext.ReadOnly = True
        Me.aboutustext.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.aboutustext.Size = New System.Drawing.Size(402, 180)
        Me.aboutustext.TabIndex = 5
        Me.aboutustext.Text = "fdg"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(33, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "1.0.0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(186, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Point Of Sale"
        '
        'backpanel
        '
        Me.backpanel.BackColor = System.Drawing.Color.Transparent
        Me.backpanel.Controls.Add(Me.panel_info)
        Me.backpanel.Controls.Add(Me.logopanel)
        Me.backpanel.Controls.Add(Me.detailpanel)
        Me.backpanel.Location = New System.Drawing.Point(0, 2)
        Me.backpanel.Name = "backpanel"
        Me.backpanel.Size = New System.Drawing.Size(741, 380)
        Me.backpanel.TabIndex = 0
        '
        'panel_info
        '
        Me.panel_info.BackColor = System.Drawing.SystemColors.ControlLight
        Me.panel_info.Controls.Add(Me.LinkLabel3)
        Me.panel_info.Controls.Add(Me.LinkLabel2)
        Me.panel_info.Controls.Add(Me.LinkLabel1)
        Me.panel_info.Location = New System.Drawing.Point(0, 295)
        Me.panel_info.Name = "panel_info"
        Me.panel_info.Size = New System.Drawing.Size(738, 83)
        Me.panel_info.TabIndex = 3
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel3.Location = New System.Drawing.Point(654, 25)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(45, 15)
        Me.LinkLabel3.TabIndex = 2
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Credits"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(344, 25)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(50, 15)
        Me.LinkLabel2.TabIndex = 1
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "License"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(28, 23)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(48, 15)
        Me.LinkLabel1.TabIndex = 0
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Authors"
        '
        'logopanel
        '
        Me.logopanel.BackgroundImage = Global.vbproject.My.Resources.Resources.logo2
        Me.logopanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.logopanel.Location = New System.Drawing.Point(1, 0)
        Me.logopanel.Name = "logopanel"
        Me.logopanel.Size = New System.Drawing.Size(302, 300)
        Me.logopanel.TabIndex = 2
        '
        'aboutUs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 380)
        Me.Controls.Add(Me.backpanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "aboutUs"
        Me.Text = "About"
        Me.detailpanel.ResumeLayout(False)
        Me.detailpanel.PerformLayout()
        Me.backpanel.ResumeLayout(False)
        Me.panel_info.ResumeLayout(False)
        Me.panel_info.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents detailpanel As Panel
    Friend WithEvents aboutustext As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents logopanel As Panel
    Friend WithEvents backpanel As Panel
    Friend WithEvents panel_info As Panel
    Friend WithEvents LinkLabel3 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
End Class
