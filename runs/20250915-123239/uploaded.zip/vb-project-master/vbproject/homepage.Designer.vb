﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class homepage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(homepage))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SaveFileDialog2 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.backgroundPanel = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.homepanelsep = New System.Windows.Forms.Panel()
        Me.billingpanelsep = New System.Windows.Forms.Panel()
        Me.roompanelsep = New System.Windows.Forms.Panel()
        Me.custompanelsep = New System.Windows.Forms.Panel()
        Me.servicepanelsep = New System.Windows.Forms.Panel()
        Me.billingpanel5 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.rightSidebarPanel = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.rightsidelastpanel = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TimeLabel = New System.Windows.Forms.Label()
        Me.sidenotepanel = New System.Windows.Forms.Panel()
        Me.sidebarnote = New System.Windows.Forms.TextBox()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YellowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndexToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.currTime = New System.Windows.Forms.Label()
        Me.customerpanel3 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.customerView = New System.Windows.Forms.DataGridView()
        Me.sideMenuPanel = New System.Windows.Forms.Panel()
        Me.roompanel4 = New System.Windows.Forms.Panel()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.roomview = New System.Windows.Forms.DataGridView()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.servicespanel2 = New System.Windows.Forms.Panel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.serviceView = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.homepanel_back = New System.Windows.Forms.Panel()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.customerAdd = New System.Windows.Forms.Button()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.NewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.aboutMenu = New System.Windows.Forms.Button()
        Me.billingMenu = New System.Windows.Forms.Button()
        Me.roomMenu = New System.Windows.Forms.Button()
        Me.customerMenu = New System.Windows.Forms.Button()
        Me.servicesMenu = New System.Windows.Forms.Button()
        Me.homeMenu = New System.Windows.Forms.Button()
        Me.FIleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NetworkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RoomServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignOutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignOutToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.backgroundPanel.SuspendLayout()
        Me.billingpanel5.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.rightSidebarPanel.SuspendLayout()
        Me.rightsidelastpanel.SuspendLayout()
        Me.sidenotepanel.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.customerpanel3.SuspendLayout()
        CType(Me.customerView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.sideMenuPanel.SuspendLayout()
        Me.roompanel4.SuspendLayout()
        CType(Me.roomview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.servicespanel2.SuspendLayout()
        CType(Me.serviceView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.homepanel_back.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "Text files|*.txt"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'backgroundPanel
        '
        Me.backgroundPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.backgroundPanel.BackColor = System.Drawing.SystemColors.Control
        Me.backgroundPanel.Controls.Add(Me.Panel3)
        Me.backgroundPanel.Controls.Add(Me.Button8)
        Me.backgroundPanel.Controls.Add(Me.homepanel_back)
        Me.backgroundPanel.Controls.Add(Me.homepanelsep)
        Me.backgroundPanel.Controls.Add(Me.billingpanelsep)
        Me.backgroundPanel.Controls.Add(Me.roompanelsep)
        Me.backgroundPanel.Controls.Add(Me.custompanelsep)
        Me.backgroundPanel.Controls.Add(Me.servicepanelsep)
        Me.backgroundPanel.Controls.Add(Me.billingpanel5)
        Me.backgroundPanel.Controls.Add(Me.rightSidebarPanel)
        Me.backgroundPanel.Controls.Add(Me.customerpanel3)
        Me.backgroundPanel.Controls.Add(Me.sideMenuPanel)
        Me.backgroundPanel.Controls.Add(Me.roompanel4)
        Me.backgroundPanel.Controls.Add(Me.MenuStrip1)
        Me.backgroundPanel.Controls.Add(Me.servicespanel2)
        Me.backgroundPanel.Location = New System.Drawing.Point(0, 2)
        Me.backgroundPanel.Name = "backgroundPanel"
        Me.backgroundPanel.Size = New System.Drawing.Size(1282, 592)
        Me.backgroundPanel.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Panel3.Location = New System.Drawing.Point(2, 580)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(200, 13)
        Me.Panel3.TabIndex = 11
        '
        'homepanelsep
        '
        Me.homepanelsep.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.homepanelsep.Location = New System.Drawing.Point(199, 29)
        Me.homepanelsep.Name = "homepanelsep"
        Me.homepanelsep.Size = New System.Drawing.Size(10, 89)
        Me.homepanelsep.TabIndex = 7
        '
        'billingpanelsep
        '
        Me.billingpanelsep.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.billingpanelsep.Location = New System.Drawing.Point(199, 395)
        Me.billingpanelsep.Name = "billingpanelsep"
        Me.billingpanelsep.Size = New System.Drawing.Size(10, 91)
        Me.billingpanelsep.TabIndex = 9
        '
        'roompanelsep
        '
        Me.roompanelsep.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.roompanelsep.Location = New System.Drawing.Point(199, 304)
        Me.roompanelsep.Name = "roompanelsep"
        Me.roompanelsep.Size = New System.Drawing.Size(10, 90)
        Me.roompanelsep.TabIndex = 8
        '
        'custompanelsep
        '
        Me.custompanelsep.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.custompanelsep.Location = New System.Drawing.Point(199, 212)
        Me.custompanelsep.Name = "custompanelsep"
        Me.custompanelsep.Size = New System.Drawing.Size(10, 91)
        Me.custompanelsep.TabIndex = 7
        '
        'servicepanelsep
        '
        Me.servicepanelsep.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.servicepanelsep.Location = New System.Drawing.Point(198, 120)
        Me.servicepanelsep.Name = "servicepanelsep"
        Me.servicepanelsep.Size = New System.Drawing.Size(10, 90)
        Me.servicepanelsep.TabIndex = 6
        '
        'billingpanel5
        '
        Me.billingpanel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.billingpanel5.Controls.Add(Me.Panel1)
        Me.billingpanel5.Controls.Add(Me.Button7)
        Me.billingpanel5.Controls.Add(Me.ListBox1)
        Me.billingpanel5.Location = New System.Drawing.Point(201, 29)
        Me.billingpanel5.Name = "billingpanel5"
        Me.billingpanel5.Size = New System.Drawing.Size(0, 0)
        Me.billingpanel5.TabIndex = 6
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.ComboBox2)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.TextBox5)
        Me.Panel1.Controls.Add(Me.ComboBox11)
        Me.Panel1.Controls.Add(Me.TextBox7)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(68, 11)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(565, 521)
        Me.Panel1.TabIndex = 0
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(31, 137)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 13)
        Me.Label11.TabIndex = 27
        Me.Label11.Text = "staying days"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(113, 132)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(189, 21)
        Me.ComboBox2.TabIndex = 26
        Me.ComboBox2.Text = "1"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(113, 185)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(195, 20)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(31, 191)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 13)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "Extra charge"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(113, 105)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(191, 21)
        Me.ComboBox1.TabIndex = 24
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(40, 36)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "room no."
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(114, 28)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(88, 26)
        Me.TextBox5.TabIndex = 1
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(113, 158)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(191, 21)
        Me.ComboBox11.TabIndex = 21
        Me.ComboBox11.Text = "0"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(111, 426)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(190, 20)
        Me.TextBox7.TabIndex = 19
        Me.TextBox7.Text = "0"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(144, 485)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(245, 17)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "current username from database"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(35, 485)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(112, 17)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Bill Submitted by"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(36, 426)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 13)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Total"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(113, 369)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(188, 20)
        Me.TextBox2.TabIndex = 3
        Me.TextBox2.Text = "0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(36, 369)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Discount"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(35, 164)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Room Price"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(36, 113)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Name"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(489, 23)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "date here.."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(447, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Date:"
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(523, 528)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(110, 35)
        Me.Button7.TabIndex = 4
        Me.Button7.Text = "Print"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(630, 11)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(126, 147)
        Me.ListBox1.TabIndex = 16
        '
        'rightSidebarPanel
        '
        Me.rightSidebarPanel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.rightSidebarPanel.BackColor = System.Drawing.SystemColors.Menu
        Me.rightSidebarPanel.Controls.Add(Me.Label5)
        Me.rightSidebarPanel.Controls.Add(Me.rightsidelastpanel)
        Me.rightSidebarPanel.Controls.Add(Me.TimeLabel)
        Me.rightSidebarPanel.Controls.Add(Me.sidenotepanel)
        Me.rightSidebarPanel.Controls.Add(Me.MonthCalendar1)
        Me.rightSidebarPanel.Controls.Add(Me.currTime)
        Me.rightSidebarPanel.Location = New System.Drawing.Point(1055, 1)
        Me.rightSidebarPanel.Name = "rightSidebarPanel"
        Me.rightSidebarPanel.Size = New System.Drawing.Size(227, 589)
        Me.rightSidebarPanel.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 195)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(130, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "place your note here...."
        '
        'rightsidelastpanel
        '
        Me.rightsidelastpanel.BackColor = System.Drawing.Color.Transparent
        Me.rightsidelastpanel.Controls.Add(Me.Label19)
        Me.rightsidelastpanel.Controls.Add(Me.Label18)
        Me.rightsidelastpanel.Controls.Add(Me.Label17)
        Me.rightsidelastpanel.Location = New System.Drawing.Point(3, 428)
        Me.rightsidelastpanel.Name = "rightsidelastpanel"
        Me.rightsidelastpanel.Size = New System.Drawing.Size(224, 161)
        Me.rightsidelastpanel.TabIndex = 2
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(21, 144)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(185, 17)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "All rights reserve to eversoft"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(45, 127)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(68, 17)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Copyright"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(119, 127)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 17)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Label17"
        '
        'TimeLabel
        '
        Me.TimeLabel.AutoSize = True
        Me.TimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimeLabel.Location = New System.Drawing.Point(89, 6)
        Me.TimeLabel.Name = "TimeLabel"
        Me.TimeLabel.Size = New System.Drawing.Size(51, 20)
        Me.TimeLabel.TabIndex = 2
        Me.TimeLabel.Text = "Time :"
        '
        'sidenotepanel
        '
        Me.sidenotepanel.BackColor = System.Drawing.Color.Transparent
        Me.sidenotepanel.Controls.Add(Me.sidebarnote)
        Me.sidenotepanel.Controls.Add(Me.MenuStrip2)
        Me.sidenotepanel.Location = New System.Drawing.Point(3, 218)
        Me.sidenotepanel.Name = "sidenotepanel"
        Me.sidenotepanel.Size = New System.Drawing.Size(227, 210)
        Me.sidenotepanel.TabIndex = 3
        '
        'sidebarnote
        '
        Me.sidebarnote.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.sidebarnote.BackColor = System.Drawing.SystemColors.Info
        Me.sidebarnote.HideSelection = False
        Me.sidebarnote.Location = New System.Drawing.Point(4, 24)
        Me.sidebarnote.Multiline = True
        Me.sidebarnote.Name = "sidebarnote"
        Me.sidebarnote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.sidebarnote.Size = New System.Drawing.Size(224, 185)
        Me.sidebarnote.TabIndex = 1
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MenuStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem1, Me.FontToolStripMenuItem, Me.ColorToolStripMenuItem, Me.FileToolStripMenuItem2, Me.EditToolStripMenuItem, Me.ToolsToolStripMenuItem1, Me.HelpToolStripMenuItem2, Me.ToolStripMenuItem1})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(136, 24)
        Me.MenuStrip2.TabIndex = 0
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.BackColor = System.Drawing.Color.Transparent
        Me.FileToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.SaveToolStripMenuItem1})
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem1.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.NewToolStripMenuItem.Text = "Clear All"
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
        Me.SaveToolStripMenuItem1.Text = "Save"
        '
        'FontToolStripMenuItem
        '
        Me.FontToolStripMenuItem.Name = "FontToolStripMenuItem"
        Me.FontToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.FontToolStripMenuItem.Text = "Font"
        '
        'ColorToolStripMenuItem
        '
        Me.ColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RedToolStripMenuItem, Me.BlueToolStripMenuItem, Me.GreenToolStripMenuItem, Me.YellowToolStripMenuItem, Me.RedToolStripMenuItem1, Me.CustomToolStripMenuItem})
        Me.ColorToolStripMenuItem.Name = "ColorToolStripMenuItem"
        Me.ColorToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.ColorToolStripMenuItem.Text = "Color"
        '
        'RedToolStripMenuItem
        '
        Me.RedToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.RedToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.RedToolStripMenuItem.Name = "RedToolStripMenuItem"
        Me.RedToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.RedToolStripMenuItem.Text = "Black"
        '
        'BlueToolStripMenuItem
        '
        Me.BlueToolStripMenuItem.Name = "BlueToolStripMenuItem"
        Me.BlueToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.BlueToolStripMenuItem.Text = "Blue"
        '
        'GreenToolStripMenuItem
        '
        Me.GreenToolStripMenuItem.Name = "GreenToolStripMenuItem"
        Me.GreenToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.GreenToolStripMenuItem.Text = "Green"
        '
        'YellowToolStripMenuItem
        '
        Me.YellowToolStripMenuItem.Name = "YellowToolStripMenuItem"
        Me.YellowToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.YellowToolStripMenuItem.Text = "Yellow"
        '
        'RedToolStripMenuItem1
        '
        Me.RedToolStripMenuItem1.Name = "RedToolStripMenuItem1"
        Me.RedToolStripMenuItem1.Size = New System.Drawing.Size(116, 22)
        Me.RedToolStripMenuItem1.Text = "Red"
        '
        'CustomToolStripMenuItem
        '
        Me.CustomToolStripMenuItem.Name = "CustomToolStripMenuItem"
        Me.CustomToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.CustomToolStripMenuItem.Text = "Custom"
        '
        'FileToolStripMenuItem2
        '
        Me.FileToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem1, Me.OpenToolStripMenuItem, Me.toolStripSeparator, Me.SaveToolStripMenuItem2, Me.SaveAsToolStripMenuItem, Me.toolStripSeparator1, Me.PrintToolStripMenuItem, Me.PrintPreviewToolStripMenuItem, Me.toolStripSeparator2, Me.ExitToolStripMenuItem1})
        Me.FileToolStripMenuItem2.Name = "FileToolStripMenuItem2"
        Me.FileToolStripMenuItem2.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem2.Text = "&File"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(143, 6)
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save &As"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(143, 6)
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(143, 6)
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(146, 22)
        Me.ExitToolStripMenuItem1.Text = "E&xit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.RedoToolStripMenuItem, Me.toolStripSeparator3, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.toolStripSeparator4, Me.SelectAllToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "&Edit"
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.UndoToolStripMenuItem.Text = "&Undo"
        '
        'RedoToolStripMenuItem
        '
        Me.RedoToolStripMenuItem.Name = "RedoToolStripMenuItem"
        Me.RedoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Y), System.Windows.Forms.Keys)
        Me.RedoToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.RedoToolStripMenuItem.Text = "&Redo"
        '
        'toolStripSeparator3
        '
        Me.toolStripSeparator3.Name = "toolStripSeparator3"
        Me.toolStripSeparator3.Size = New System.Drawing.Size(141, 6)
        '
        'toolStripSeparator4
        '
        Me.toolStripSeparator4.Name = "toolStripSeparator4"
        Me.toolStripSeparator4.Size = New System.Drawing.Size(141, 6)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select &All"
        '
        'ToolsToolStripMenuItem1
        '
        Me.ToolsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomizeToolStripMenuItem, Me.OptionsToolStripMenuItem})
        Me.ToolsToolStripMenuItem1.Name = "ToolsToolStripMenuItem1"
        Me.ToolsToolStripMenuItem1.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem1.Text = "&Tools"
        '
        'CustomizeToolStripMenuItem
        '
        Me.CustomizeToolStripMenuItem.Name = "CustomizeToolStripMenuItem"
        Me.CustomizeToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.CustomizeToolStripMenuItem.Text = "&Customize"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.OptionsToolStripMenuItem.Text = "&Options"
        '
        'HelpToolStripMenuItem2
        '
        Me.HelpToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentsToolStripMenuItem, Me.IndexToolStripMenuItem, Me.SearchToolStripMenuItem, Me.toolStripSeparator5, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem2.Name = "HelpToolStripMenuItem2"
        Me.HelpToolStripMenuItem2.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem2.Text = "&Help"
        '
        'ContentsToolStripMenuItem
        '
        Me.ContentsToolStripMenuItem.Name = "ContentsToolStripMenuItem"
        Me.ContentsToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.ContentsToolStripMenuItem.Text = "&Contents"
        '
        'IndexToolStripMenuItem
        '
        Me.IndexToolStripMenuItem.Name = "IndexToolStripMenuItem"
        Me.IndexToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.IndexToolStripMenuItem.Text = "&Index"
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.SearchToolStripMenuItem.Text = "&Search"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(119, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.AboutToolStripMenuItem.Text = "&About..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(49, 20)
        Me.ToolStripMenuItem1.Text = "Clear "
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MonthCalendar1.Location = New System.Drawing.Point(0, 27)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 1
        '
        'currTime
        '
        Me.currTime.AutoSize = True
        Me.currTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.currTime.Location = New System.Drawing.Point(140, 6)
        Me.currTime.Name = "currTime"
        Me.currTime.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.currTime.Size = New System.Drawing.Size(0, 20)
        Me.currTime.TabIndex = 0
        '
        'customerpanel3
        '
        Me.customerpanel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.customerpanel3.Controls.Add(Me.Button3)
        Me.customerpanel3.Controls.Add(Me.TextBox3)
        Me.customerpanel3.Controls.Add(Me.Label4)
        Me.customerpanel3.Controls.Add(Me.customerView)
        Me.customerpanel3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.customerpanel3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.customerpanel3.Location = New System.Drawing.Point(201, 29)
        Me.customerpanel3.Name = "customerpanel3"
        Me.customerpanel3.Size = New System.Drawing.Size(0, 0)
        Me.customerpanel3.TabIndex = 1
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(743, 35)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(101, 26)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Search"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(589, 37)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(148, 24)
        Me.TextBox3.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(23, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(164, 20)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "All Staying Customers"
        '
        'customerView
        '
        Me.customerView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.customerView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.customerView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.customerView.Location = New System.Drawing.Point(13, 63)
        Me.customerView.Name = "customerView"
        Me.customerView.Size = New System.Drawing.Size(841, 500)
        Me.customerView.TabIndex = 0
        '
        'sideMenuPanel
        '
        Me.sideMenuPanel.BackColor = System.Drawing.SystemColors.Control
        Me.sideMenuPanel.Controls.Add(Me.aboutMenu)
        Me.sideMenuPanel.Controls.Add(Me.billingMenu)
        Me.sideMenuPanel.Controls.Add(Me.roomMenu)
        Me.sideMenuPanel.Controls.Add(Me.customerMenu)
        Me.sideMenuPanel.Controls.Add(Me.servicesMenu)
        Me.sideMenuPanel.Controls.Add(Me.homeMenu)
        Me.sideMenuPanel.Location = New System.Drawing.Point(2, 26)
        Me.sideMenuPanel.Name = "sideMenuPanel"
        Me.sideMenuPanel.Size = New System.Drawing.Size(199, 557)
        Me.sideMenuPanel.TabIndex = 0
        '
        'roompanel4
        '
        Me.roompanel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.roompanel4.Controls.Add(Me.TextBox6)
        Me.roompanel4.Controls.Add(Me.Button11)
        Me.roompanel4.Controls.Add(Me.Label3)
        Me.roompanel4.Controls.Add(Me.roomview)
        Me.roompanel4.Controls.Add(Me.Button6)
        Me.roompanel4.Controls.Add(Me.Button5)
        Me.roompanel4.Controls.Add(Me.Button2)
        Me.roompanel4.Location = New System.Drawing.Point(201, 29)
        Me.roompanel4.Name = "roompanel4"
        Me.roompanel4.Size = New System.Drawing.Size(0, 0)
        Me.roompanel4.TabIndex = 5
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(198, 282)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(147, 24)
        Me.TextBox6.TabIndex = 9
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(349, 280)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(103, 28)
        Me.Button11.TabIndex = 8
        Me.Button11.Text = "Search"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(14, 275)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 20)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "All room details"
        '
        'roomview
        '
        Me.roomview.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.roomview.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.roomview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.roomview.Location = New System.Drawing.Point(9, 312)
        Me.roomview.Name = "roomview"
        Me.roomview.Size = New System.Drawing.Size(442, 251)
        Me.roomview.TabIndex = 6
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button6.Location = New System.Drawing.Point(253, 159)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(190, 64)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "update Room"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button5.Location = New System.Drawing.Point(354, 49)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(190, 64)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Delete Room"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(111, 55)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(190, 64)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Add  Room"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FIleToolStripMenuItem, Me.NetworkToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.SignOutToolStripMenuItem, Me.SignOutToolStripMenuItem1, Me.SignOutToolStripMenuItem2})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1282, 29)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'servicespanel2
        '
        Me.servicespanel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.servicespanel2.Controls.Add(Me.Button9)
        Me.servicespanel2.Controls.Add(Me.TextBox4)
        Me.servicespanel2.Controls.Add(Me.Button4)
        Me.servicespanel2.Controls.Add(Me.serviceView)
        Me.servicespanel2.Controls.Add(Me.Label1)
        Me.servicespanel2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.servicespanel2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.servicespanel2.Location = New System.Drawing.Point(201, 29)
        Me.servicespanel2.Name = "servicespanel2"
        Me.servicespanel2.Size = New System.Drawing.Size(0, 0)
        Me.servicespanel2.TabIndex = 1
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button9.Location = New System.Drawing.Point(518, 97)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(190, 64)
        Me.Button9.TabIndex = 4
        Me.Button9.Text = "Delete Services"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(142, 72)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(125, 24)
        Me.TextBox4.TabIndex = 3
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(271, 70)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(103, 28)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "Search"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'serviceView
        '
        Me.serviceView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.serviceView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.serviceView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.serviceView.Location = New System.Drawing.Point(14, 104)
        Me.serviceView.Name = "serviceView"
        Me.serviceView.Size = New System.Drawing.Size(356, 460)
        Me.serviceView.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(14, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "All Services"
        '
        'PrintDocument1
        '
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Image = Global.vbproject.My.Resources.Resources.refresh1
        Me.Button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.Location = New System.Drawing.Point(938, 1)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(111, 26)
        Me.Button8.TabIndex = 10
        Me.Button8.Text = "Refresh"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'homepanel_back
        '
        Me.homepanel_back.BackColor = System.Drawing.Color.Transparent
        Me.homepanel_back.BackgroundImage = Global.vbproject.My.Resources.Resources.background
        Me.homepanel_back.Controls.Add(Me.ComboBox4)
        Me.homepanel_back.Controls.Add(Me.Button10)
        Me.homepanel_back.Controls.Add(Me.Button1)
        Me.homepanel_back.Controls.Add(Me.customerAdd)
        Me.homepanel_back.Controls.Add(Me.ComboBox3)
        Me.homepanel_back.Location = New System.Drawing.Point(201, 29)
        Me.homepanel_back.Name = "homepanel_back"
        Me.homepanel_back.Size = New System.Drawing.Size(859, 563)
        Me.homepanel_back.TabIndex = 7
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(405, 219)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(91, 21)
        Me.ComboBox4.TabIndex = 4
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button10.Location = New System.Drawing.Point(306, 246)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(190, 64)
        Me.Button10.TabIndex = 2
        Me.Button10.Text = "Send Mail"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(456, 91)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(190, 64)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Add Services"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'customerAdd
        '
        Me.customerAdd.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.customerAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.customerAdd.Font = New System.Drawing.Font("Footlight MT Light", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.customerAdd.ForeColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.customerAdd.Location = New System.Drawing.Point(145, 89)
        Me.customerAdd.Name = "customerAdd"
        Me.customerAdd.Size = New System.Drawing.Size(190, 64)
        Me.customerAdd.TabIndex = 0
        Me.customerAdd.Text = "Add Customer"
        Me.customerAdd.UseVisualStyleBackColor = False
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(305, 219)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(94, 21)
        Me.ComboBox3.TabIndex = 3
        '
        'NewToolStripMenuItem1
        '
        Me.NewToolStripMenuItem1.Image = CType(resources.GetObject("NewToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.NewToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripMenuItem1.Name = "NewToolStripMenuItem1"
        Me.NewToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewToolStripMenuItem1.Size = New System.Drawing.Size(146, 22)
        Me.NewToolStripMenuItem1.Text = "&New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Image = CType(resources.GetObject("OpenToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.OpenToolStripMenuItem.Text = "&Open"
        '
        'SaveToolStripMenuItem2
        '
        Me.SaveToolStripMenuItem2.Image = CType(resources.GetObject("SaveToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripMenuItem2.Name = "SaveToolStripMenuItem2"
        Me.SaveToolStripMenuItem2.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveToolStripMenuItem2.Size = New System.Drawing.Size(146, 22)
        Me.SaveToolStripMenuItem2.Text = "&Save"
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Image = CType(resources.GetObject("PrintToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.PrintToolStripMenuItem.Text = "&Print"
        '
        'PrintPreviewToolStripMenuItem
        '
        Me.PrintPreviewToolStripMenuItem.Image = CType(resources.GetObject("PrintPreviewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintPreviewToolStripMenuItem.Name = "PrintPreviewToolStripMenuItem"
        Me.PrintPreviewToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.PrintPreviewToolStripMenuItem.Text = "Print Pre&view"
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Image = CType(resources.GetObject("CutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.CutToolStripMenuItem.Text = "Cu&t"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.CopyToolStripMenuItem.Text = "&Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Image = CType(resources.GetObject("PasteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.PasteToolStripMenuItem.Text = "&Paste"
        '
        'aboutMenu
        '
        Me.aboutMenu.BackgroundImage = Global.vbproject.My.Resources.Resources.aboutus
        Me.aboutMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.aboutMenu.FlatAppearance.BorderSize = 0
        Me.aboutMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.aboutMenu.Location = New System.Drawing.Point(1, 461)
        Me.aboutMenu.Name = "aboutMenu"
        Me.aboutMenu.Size = New System.Drawing.Size(197, 92)
        Me.aboutMenu.TabIndex = 5
        Me.aboutMenu.UseVisualStyleBackColor = True
        '
        'billingMenu
        '
        Me.billingMenu.BackgroundImage = Global.vbproject.My.Resources.Resources.billing
        Me.billingMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.billingMenu.FlatAppearance.BorderSize = 0
        Me.billingMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.billingMenu.Location = New System.Drawing.Point(1, 369)
        Me.billingMenu.Name = "billingMenu"
        Me.billingMenu.Size = New System.Drawing.Size(197, 91)
        Me.billingMenu.TabIndex = 4
        Me.billingMenu.UseVisualStyleBackColor = True
        '
        'roomMenu
        '
        Me.roomMenu.BackgroundImage = Global.vbproject.My.Resources.Resources.rooms
        Me.roomMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.roomMenu.FlatAppearance.BorderSize = 0
        Me.roomMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.roomMenu.Location = New System.Drawing.Point(1, 278)
        Me.roomMenu.Name = "roomMenu"
        Me.roomMenu.Size = New System.Drawing.Size(197, 90)
        Me.roomMenu.TabIndex = 3
        Me.roomMenu.UseVisualStyleBackColor = True
        '
        'customerMenu
        '
        Me.customerMenu.BackgroundImage = Global.vbproject.My.Resources.Resources.customer
        Me.customerMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.customerMenu.FlatAppearance.BorderSize = 0
        Me.customerMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.customerMenu.Location = New System.Drawing.Point(1, 186)
        Me.customerMenu.Name = "customerMenu"
        Me.customerMenu.Size = New System.Drawing.Size(197, 91)
        Me.customerMenu.TabIndex = 2
        Me.customerMenu.UseVisualStyleBackColor = True
        '
        'servicesMenu
        '
        Me.servicesMenu.BackgroundImage = Global.vbproject.My.Resources.Resources.services
        Me.servicesMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.servicesMenu.FlatAppearance.BorderSize = 0
        Me.servicesMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.servicesMenu.Location = New System.Drawing.Point(1, 94)
        Me.servicesMenu.Name = "servicesMenu"
        Me.servicesMenu.Size = New System.Drawing.Size(197, 90)
        Me.servicesMenu.TabIndex = 1
        Me.servicesMenu.UseVisualStyleBackColor = True
        '
        'homeMenu
        '
        Me.homeMenu.BackgroundImage = Global.vbproject.My.Resources.Resources.home
        Me.homeMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.homeMenu.FlatAppearance.BorderSize = 0
        Me.homeMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.homeMenu.Location = New System.Drawing.Point(1, 3)
        Me.homeMenu.Name = "homeMenu"
        Me.homeMenu.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.homeMenu.Size = New System.Drawing.Size(197, 89)
        Me.homeMenu.TabIndex = 0
        Me.homeMenu.UseVisualStyleBackColor = True
        '
        'FIleToolStripMenuItem
        '
        Me.FIleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem2})
        Me.FIleToolStripMenuItem.Image = Global.vbproject.My.Resources.Resources.folder
        Me.FIleToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.FIleToolStripMenuItem.Name = "FIleToolStripMenuItem"
        Me.FIleToolStripMenuItem.Size = New System.Drawing.Size(62, 25)
        Me.FIleToolStripMenuItem.Text = "FIle"
        '
        'ExitToolStripMenuItem2
        '
        Me.ExitToolStripMenuItem2.Image = Global.vbproject.My.Resources.Resources._exit
        Me.ExitToolStripMenuItem2.Name = "ExitToolStripMenuItem2"
        Me.ExitToolStripMenuItem2.Size = New System.Drawing.Size(104, 26)
        Me.ExitToolStripMenuItem2.Text = "Exit"
        '
        'NetworkToolStripMenuItem
        '
        Me.NetworkToolStripMenuItem.Image = Global.vbproject.My.Resources.Resources.connection
        Me.NetworkToolStripMenuItem.Name = "NetworkToolStripMenuItem"
        Me.NetworkToolStripMenuItem.Size = New System.Drawing.Size(98, 25)
        Me.NetworkToolStripMenuItem.Text = "Network"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ServicesToolStripMenuItem, Me.CustomerToolStripMenuItem, Me.RoomServicesToolStripMenuItem, Me.BillingToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Image = Global.vbproject.My.Resources.Resources.tools
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(73, 25)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'ServicesToolStripMenuItem
        '
        Me.ServicesToolStripMenuItem.Name = "ServicesToolStripMenuItem"
        Me.ServicesToolStripMenuItem.Size = New System.Drawing.Size(183, 26)
        Me.ServicesToolStripMenuItem.Text = "Services"
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(183, 26)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        '
        'RoomServicesToolStripMenuItem
        '
        Me.RoomServicesToolStripMenuItem.Name = "RoomServicesToolStripMenuItem"
        Me.RoomServicesToolStripMenuItem.Size = New System.Drawing.Size(183, 26)
        Me.RoomServicesToolStripMenuItem.Text = "Room Services"
        '
        'BillingToolStripMenuItem
        '
        Me.BillingToolStripMenuItem.Name = "BillingToolStripMenuItem"
        Me.BillingToolStripMenuItem.Size = New System.Drawing.Size(183, 26)
        Me.BillingToolStripMenuItem.Text = "Billing"
        '
        'SignOutToolStripMenuItem
        '
        Me.SignOutToolStripMenuItem.Image = Global.vbproject.My.Resources.Resources.settings
        Me.SignOutToolStripMenuItem.Name = "SignOutToolStripMenuItem"
        Me.SignOutToolStripMenuItem.Size = New System.Drawing.Size(87, 25)
        Me.SignOutToolStripMenuItem.Text = "Setting"
        '
        'SignOutToolStripMenuItem1
        '
        Me.SignOutToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem, Me.AboutUsToolStripMenuItem})
        Me.SignOutToolStripMenuItem1.Image = Global.vbproject.My.Resources.Resources.info
        Me.SignOutToolStripMenuItem1.Name = "SignOutToolStripMenuItem1"
        Me.SignOutToolStripMenuItem1.Size = New System.Drawing.Size(70, 25)
        Me.SignOutToolStripMenuItem1.Text = "Help"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Image = Global.vbproject.My.Resources.Resources.help_1
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(214, 26)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutUsToolStripMenuItem
        '
        Me.AboutUsToolStripMenuItem.Image = Global.vbproject.My.Resources.Resources.about_us
        Me.AboutUsToolStripMenuItem.Name = "AboutUsToolStripMenuItem"
        Me.AboutUsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.AboutUsToolStripMenuItem.Size = New System.Drawing.Size(214, 26)
        Me.AboutUsToolStripMenuItem.Text = "About Us"
        '
        'SignOutToolStripMenuItem2
        '
        Me.SignOutToolStripMenuItem2.Image = Global.vbproject.My.Resources.Resources.logout
        Me.SignOutToolStripMenuItem2.Name = "SignOutToolStripMenuItem2"
        Me.SignOutToolStripMenuItem2.Size = New System.Drawing.Size(99, 25)
        Me.SignOutToolStripMenuItem2.Text = "Sign Out"
        '
        'homepage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 593)
        Me.Controls.Add(Me.backgroundPanel)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "homepage"
        Me.Text = "POS SYSTEM"
        Me.backgroundPanel.ResumeLayout(False)
        Me.backgroundPanel.PerformLayout()
        Me.billingpanel5.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.rightSidebarPanel.ResumeLayout(False)
        Me.rightSidebarPanel.PerformLayout()
        Me.rightsidelastpanel.ResumeLayout(False)
        Me.rightsidelastpanel.PerformLayout()
        Me.sidenotepanel.ResumeLayout(False)
        Me.sidenotepanel.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.customerpanel3.ResumeLayout(False)
        Me.customerpanel3.PerformLayout()
        CType(Me.customerView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.sideMenuPanel.ResumeLayout(False)
        Me.roompanel4.ResumeLayout(False)
        Me.roompanel4.PerformLayout()
        CType(Me.roomview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.servicespanel2.ResumeLayout(False)
        Me.servicespanel2.PerformLayout()
        CType(Me.serviceView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.homepanel_back.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents backgroundPanel As Panel
    Friend WithEvents sideMenuPanel As Panel
    Friend WithEvents homeMenu As Button
    Friend WithEvents customerMenu As Button
    Friend WithEvents servicesMenu As Button
    Friend WithEvents aboutMenu As Button
    Friend WithEvents billingMenu As Button
    Friend WithEvents roomMenu As Button
    Friend WithEvents rightSidebarPanel As Panel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents currTime As Label
    Friend WithEvents MonthCalendar1 As MonthCalendar
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FIleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NetworkToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ServicesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RoomServicesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BillingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SignOutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SignOutToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents TimeLabel As Label
    Friend WithEvents sidenotepanel As Panel
    Friend WithEvents sidebarnote As TextBox
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents FileToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FontToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents FontDialog1 As FontDialog
    Friend WithEvents SaveFileDialog2 As SaveFileDialog
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents RedToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BlueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents YellowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RedToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CustomToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator As ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator1 As ToolStripSeparator
    Friend WithEvents PrintToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintPreviewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator3 As ToolStripSeparator
    Friend WithEvents CutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator4 As ToolStripSeparator
    Friend WithEvents SelectAllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CustomizeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ContentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IndexToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SignOutToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents rightsidelastpanel As Panel
    Friend WithEvents billingpanel5 As Panel
    Friend WithEvents customerpanel3 As Panel
    Friend WithEvents roompanel4 As Panel
    Friend WithEvents servicespanel2 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents homepanel_back As Panel
    Friend WithEvents servicepanelsep As Panel
    Friend WithEvents custompanelsep As Panel
    Friend WithEvents roompanelsep As Panel
    Friend WithEvents billingpanelsep As Panel
    Friend WithEvents homepanelsep As Panel
    Friend WithEvents customerAdd As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents customerView As DataGridView
    Friend WithEvents Button3 As Button
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents serviceView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents roomview As DataGridView
    Friend WithEvents Button8 As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Button11 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents ComboBox4 As ComboBox
End Class
