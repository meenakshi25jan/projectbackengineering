# vb-project
This is a vb.net project, done by @dhpradeep as on 10th Nov 2017

you can test this application by only download :
> vbproject/bin folder, and run vbproject.exe file.

If you need any help just comment or mail me
mail address: dhpradeep25@gmail.com

<i><b> project details: </b></i>

'for admin

<code>
username: admin

password: user12345
</code>

'for user

<code>
username: user

password: user12345
</code>

'for database

<code>
password: login1234
</code>

some functions (forget password,send mail) doesn't work until you provide your email & password for admin account.

So for completely test this application you have to insert your email & password from here:

<i><code> home > settings > update email & password </code></i>

<h5><i> User does't have permission to use email features. </i></h5>

# Thank you everyone.

