vb6-crud
========

A complete almost automatic CRUD system for VB6 projects.
You will only need to define the fields for your form, its names for the database, 
and its types (numeric, date or string).